#' Return the estimated parameters when fitting collected serial interval into weibull distribution
#' 
#' requires packages:
#'      readxl
#' 
#' @param datafile input of the excel file which requires a sheet named `Cluster`, the datafile name should be a complete string with the postfix `.xlsx`; additionally, the `xlsx` file must contain sheet including detailed information of all confirmed cases, named `Information`.
#' @return a vector including the fitted shape and scale parameters after fitting collected data to weibull distribution
#' @examples 
#' cReturn <- EstimateSerial('transmission_data_hebei.xlsx', alp.t = 1/3.85, n.p = 194/(194+942))
#' @export

EstimateSerial <- function(datafile){
    options(warn = -1)
    # retrieve date
    data <- read_excel(datafile, sheet = 'Cluster')
    data_date <- read_excel(datafile, sheet = 'Information')
    set.seed(1234)
    id1 = as.character(data$PrimaryID)
    id2 = as.character(data$ID)
    id_index = as.character(data_date$id)
    Onset_date = as.Date(data_date$onset_date)
    prim_id = id1[id1 != id2]
    sec_id = id2[id1 != id2]
    save_serial = rep(NA, 0)
    nnid <- length(prim_id)
    for (i in 1:nnid){
        jd = prim_id[i]
        if(length(strsplit(jd, ';')[[1]]) == 1){
            if(!is.na(Onset_date[which(id_index == jd)])){
                start = Onset_date[which(id_index == jd)]
                for (ed in strsplit(sec_id[i], ';')[[1]]){
                    if (!is.na(Onset_date[which(id_index == ed)])){
                        end = Onset_date[which(id_index == ed)]
                        save_serial = c(save_serial, as.numeric(difftime(end, start, units = 'days')))
                    }
                }
            }
        }
    }
    useful = save_serial[save_serial > 0]
    est_serial <- function(para){
        temp <- dweibull(useful, shape = para[1], scale = para[2], log = TRUE)
        return(-sum(temp))
    }
    rot <- nlm(est_serial, c(1, 1))$est
    return(c(rot[1], rot[2]))
}


#' Compare the difference of median serial interval from two samples using likelihood ratio test
#' 
#' requires packages:
#'      readxl
#' 
#' @param datafile1 input of the excel file which requires a sheet named `Cluster`, the datafile name should be a complete string with the postfix `.xlsx`; additionally, the `xlsx` file must contain sheet including detailed information of all confirmed cases, named `Information`.
#' @param datafile2 symmetric file to be compared with `datafile1`
#' @return the p-value under `H_0: m_1 = m_2` where `m` denotes the median serial intervals
#' @examples 
#' cReturn <- CompareSerial('transmission_data_hebei.xlsx', 'transmission_data_tianjin.xlsx')
#' @export

CompareSerial <- function(datafile1, datafile2){
    options(warn = -1)
    set.seed(1234)
    data <- read_excel(datafile1, sheet = 'Cluster')
    data <- data[!is.na(data$PrimaryID), ]
    data_date <- read_excel(datafile1, sheet = 'Information')
    id1 = as.character(data$PrimaryID)
    id2 = as.character(data$ID)
    id_index = as.character(data_date$id)
    Onset_date = as.Date(data_date$onset_date)
    prim_id = id1[id1 != id2]
    sec_id = id2[id1 != id2]
    save_serial = rep(NA, 0)
    nnid <- length(prim_id)
    for (i in 1:nnid){
        jd = prim_id[i]
        if(length(strsplit(jd, ';')[[1]]) == 1){
            if(!is.na(Onset_date[which(id_index == jd)])){
                start = Onset_date[which(id_index == jd)]
                for (ed in strsplit(sec_id[i], ';')[[1]]){
                    if (!is.na(Onset_date[which(id_index == ed)])){
                        end = Onset_date[which(id_index == ed)]
                        save_serial = c(save_serial, as.numeric(difftime(end, start, units = 'days')))
                    }
                }
            }
        }
    }
    use_city1 <- save_serial[save_serial > 0]
    
    data <- read_excel(datafile2, sheet = 'Cluster')
    data <- data[!is.na(data$PrimaryID), ]
    data_date <- read_excel(datafile2, sheet = 'Information')
    id1 = as.character(data$PrimaryID)
    id2 = as.character(data$ID)
    id_index = as.character(data_date$id)
    Onset_date = as.Date(data_date$onset_date)
    prim_id = id1[id1 != id2]
    sec_id = id2[id1 != id2]
    save_serial = rep(NA, 0)
    nnid <- length(prim_id)
    for (i in 1:nnid){
        jd = prim_id[i]
        if(length(strsplit(jd, ';')[[1]]) == 1){
            if(!is.na(Onset_date[which(id_index == jd)])){
                start = Onset_date[which(id_index == jd)]
                for (ed in strsplit(sec_id[i], ';')[[1]]){
                    if (!is.na(Onset_date[which(id_index == ed)])){
                        end = Onset_date[which(id_index == ed)]
                        save_serial = c(save_serial, as.numeric(difftime(end, start, units = 'days')))
                    }
                }
            }
        }
    }
    use_city2 = save_serial[save_serial > 0]
    
    # est_hebei
    est_serial <- function(para){
        temp <- dweibull(use_city1, shape = para[1], scale = para[2], log = TRUE)
        return(-sum(temp))
    }
    rottt <- nlm(est_serial, c(1, 1))$est
    l_city1 <- est_serial(rottt)
    
    # est_tianjin
    est_serial <- function(para){
        temp <- dweibull(use_city2, shape = para[1], scale = para[2], log = TRUE)
        return(-sum(temp))
    }
    rottt <- nlm(est_serial, c(1, 1))$est
    l_city2 <- est_serial(rottt)
    
    # est_both
    est_serial <- function(para){
        temp1 <- dweibull(use_city1, shape = para[1], scale = para[2], log = TRUE)
        b2 <- para[2]*exp(log(log(2))*(1/para[1] - 1/para[3]))
        temp2 <- dweibull(use_city2, shape = para[3], scale = b2, log = TRUE)
        return(-sum(temp1) - sum(temp2))
    }
    rottt <- nlm(est_serial, c(1, 1, 1))$est
    l_both <- est_serial(rottt)
    
    print(pchisq(2*(l_both - l_city1 - l_city2), df = 1, lower.tail = FALSE))
}
