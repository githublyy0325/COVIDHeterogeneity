#' Simulate secondary infections
#' 
#' Simulate the size of secondary infections as of a specific date, under a prefixed `R` and `k`, by the way, simualte the overall size of infections after a proportion of population being vaccinated
#' 
#' requires packages:
#'      readxl
#'      fitdistrplus
#' 
#' @param datafile input of the excel file which requires a sheet named `Cluster`, the datafile name should be a complete string with the postfix `.xlsx`; additionally, the `xlsx` file must contain sheet including detailed information of all confirmed cases, named `Information`. 
#' @param alp.t input of the predefined ratio of the infectiousness of asymptomatic cases compared to that of symptomatic cases
#' @param n.p input of proportion of asymptomatic cases among the population (susceptible population)
#' @param numofasym input of the number of asymptomatic cases to be imputed
#' @param R input of the predefined average reproductive number `R`
#' @param k input of the heterogeneity parameter `k`
#' @param c_effect the predefined efficacy of vaccination
#' @param p_ctrl the proportion of population under control(non pharmaceutical interventions or vaccinations)
#' @param start.date the first date to be wanted in the simulation results
#' @param end.date the last date to be wanted in the simulation results
#' @param gtshape assuming the generation time follows a weibull distribution, this parameter denotes the scale parameter of weibull distribution
#' @param gtscale the scale parameter of weibull distribution in fitting generation time
#' @return a dataframe including the 95% lower, mean and 95% upper for each col, from the starting date to ending date.
#' @examples 
#' cReturn <- SimulateSize('transmission_data_hebei.xlsx', alp.t = 1/3.85, n.p = 0.17, R = 0.5, k = 0.4, c_effect = 0.8, p_ctrl = 0.6, start.date = '2021/1/1', end.date = '2021/3/31', gtshape = 2.01, gtscale = 6.1)
#' @export

SimulateSize <- function(datafile, alp.t = 1/3.85, n.p = 0.17, numofasym = 194, R = 0.5, k = 0.4, c_effect = 0.8, p_ctrl = 0.6, start.date = '2021/1/1', end.date = '2021/3/31', gtshape = 2.01, gtscale = 6.1){
  options(warn = -1)
  # retrieve date
  data <- read_excel(datafile, sheet = 'Cluster')
  data_date <- read_excel(datafile, sheet = 'Information')
  set.seed(1234)
  indicator = data$ChainSize - data$PrimaryNum
  alloc = rowSums(rmultinom(numofasym, 1, indicator/sum(indicator)))
  data$ChainSize = data$ChainSize + alloc
  set.seed(1234)
  # to fit for the delay between onset to confirmed date
  ind.onset <- as.logical(1-is.na(data_date$onset_date))
  onset_n <- as.Date(data_date$onset_date[ind.onset])
  confirm_n <- as.Date(data_date$confirmed_date[ind.onset])
  delay_n <- as.numeric(difftime(confirm_n, onset_n, units = 'days'))
  
  # assume if follows weibull distribution [the delay]
  neglogl_ <- function(para){
    alp = para[1]
    beta = para[2]
    res = dweibull(delay_n+0.5, shape = alp, scale = beta, log = TRUE)
    return(-sum(res))
  }
  rot_new = nlm(f = neglogl_, p = c(1, 1))$est
  
  # begin simulation
  tosetonedate <- as.Date(start.date)
  primary_id <- as.character(data$PrimaryID)
  ID_index <- as.character(data_date$id)
  Onset_date <- as.numeric(difftime(as.Date(data_date$onset_date), tosetonedate))+1
  Confirmed_date <- as.numeric(difftime(as.Date(data_date$confirmed_date), tosetonedate))+1
  range_date <- as.numeric(difftime(as.Date(end.date), tosetonedate))+1
  
  # initial clusters
  vec_id = rep(NA, 0)
  for (id in primary_id){
    gr <- strsplit(id, ';')[[1]]
    if(length(gr) != 1){
      vec_id = c(vec_id, gr)
    }else{vec_id = c(vec_id, id)}
  }
  clust_list = list()
  prim_date = rep(NA, 0)
  for (j in 1:length(vec_id)){
    clust_list[[j]] = list()
    clust_list[[j]]$id = vec_id[j]
    clust_list[[j]]$cases = c(1)
    if (is.na(Onset_date[which(ID_index == vec_id[j])])){
      clust_list[[j]]$date = Confirmed_date[which(ID_index == vec_id[j])] -
        round(rweibull(1, shape = rot_new[1], scale = rot_new[2]))
    }else{
      clust_list[[j]]$date = Onset_date[which(ID_index == vec_id[j])]
    }
    prim_date = c(prim_date, clust_list[[j]]$date)
  }
  
  # baseline
  clust_save <- clust_list
  t_set <- 1:range_date
  casebase_upto_T <- function(t){
    func2 <- function(y){
      return(sum(y$cases[which(y$date <= t)]))
    }
    return(sum(sapply(clust_save, func2)))
  }
  base_line <- sapply(t_set, casebase_upto_T)
  B = 1000
  base_line <- matrix(rep(base_line, B), nrow = B, byrow = TRUE)
  
  # begin simulation
  R0 = R
  R0_sp = R*(1-c_effect)
  clust_post <- clust_post_indv <- list()
  
  func_prune <- function(x, y){
    if(rbinom(1, 1, prob = p_ctrl) == 1){
      return(x)
    }else{return(y)}
  }
  for (ik in 1:B){
    simul <- function(x){
      num_of_case = 1
      asymp_case = as.logical(rbinom(num_of_case, 1, prob = n.p))
      child_case = sum(rnbinom(num_of_case, size = k, prob = k/(alp.t*R0+k))[asymp_case]) + 
        sum(rnbinom(num_of_case, size = k, prob = k/(R0+k))[!asymp_case])
      while(child_case != 0){
        d_time = rweibull(1, shape = gtshape, scale = gtscale)
        x$date = c(x$date, x$date[length(x$date)] + d_time)
        x$cases = c(x$cases, child_case)
        num_of_case = x$cases[length(x$cases)]
        asymp_case = as.logical(rbinom(num_of_case, 1, prob = n.p))
        child_case = sum(rnbinom(num_of_case, size = k, prob = k/(alp.t*R0+k))[asymp_case]) + 
          sum(rnbinom(num_of_case, size = k, prob = k/(R0+k))[!asymp_case])
      }
      return(x)
    }
    clust_post[[ik]] <- lapply(clust_list, simul)
    
    simul_sp <- function(x){
      num_of_case = 1
      asymp_case = as.logical(rbinom(num_of_case, 1, prob = n.p))
      child_case = sum(rnbinom(num_of_case, size = k, prob = k/(alp.t*R0_sp+k))[asymp_case]) + 
        sum(rnbinom(num_of_case, size = k, prob = k/(R0_sp+k))[!asymp_case])
      while(child_case != 0){
        d_time = rweibull(1, shape = gtshape, scale = gtscale)
        x$date = c(x$date, x$date[length(x$date)] + d_time)
        x$cases = c(x$cases, child_case)
        num_of_case = x$cases[length(x$cases)]
        asymp_case = as.logical(rbinom(num_of_case, 1, prob = n.p))
        child_case = sum(rnbinom(num_of_case, size = k, prob = k/(alp.t*R0_sp+k))[asymp_case]) + 
          sum(rnbinom(num_of_case, size = k, prob = k/(R0_sp+k))[!asymp_case])
      }
      return(x)
    }
    clust_post_indv[[ik]] <- lapply(clust_list, simul_sp)
    clust_post_indv[[ik]] <- mapply(func_prune, clust_post_indv[[ik]], clust_post[[ik]], SIMPLIFY = FALSE)
    
  }
  
  case_upto_T <- function(t){
    func1 <- function(x){
      func2 <- function(y){
        return(sum(y$cases[which(y$date <= t)]))
      }
      return(sum(sapply(x, func2)))
    }
    return(sapply(clust_post_indv, func1))
  }
  rst <- sapply(t_set, case_upto_T) - base_line
  func_95conf <- function(x){
    return(c(sort(x)[25], mean(x), sort(x)[975]))
  }
  conf_ind <- as.data.frame(t(apply(rst, 2, func_95conf)))
  colnames(conf_ind) = c('95lower', 'mean', '95upper')
  rownames(conf_ind) = seq.Date(from = as.Date(start.date), to = as.Date(end.date), by = 'days')
  return(conf_ind)
}