#' Return estimate of R and k by maximizing the likelihood 
#' 
#' requires packages:
#'      readxl
#'      fitdistrplus
#' 
#' @param datafile input of the excel file which requires a sheet named `Cluster`, the datafile name should be a complete string with the postfix `.xlsx`
#' @param alp.t input of the predefined ratio of the infectiousness of asymptomatic cases compared to that of symptomatic cases
#' @param n.p input of proportion of asymptomatic cases among the population (susceptible population)
#' @param numofasym input of the number of asymptomatic cases to be imputed
#' @return a vector including estimated `R` and `k`
#' @examples 
#' cReturn <- ReturnEstimation('transmission_data_hebei.xlsx', alp.t = 1/3.85, n.p = 194/(194+942))
#' @export

ReturnEstimation <- function(datafile, alp.t = 1/3.85, n.p = 0.17, numofasym = 194){
  options(warn = -1)
  # retrieve date
  data <- read_excel(datafile, sheet = 'Cluster')
  set.seed(1234)
  indicator = data$ChainSize - data$PrimaryNum
  alloc = rowSums(rmultinom(numofasym, 1, indicator/sum(indicator)))
  data$ChainSize = data$ChainSize + alloc
  ind.A <- data$ClusterType=='A'
  ind.AB <- (data$ClusterType %in% c('AB', 'B')) & (!is.na(data$PrimaryNum))
  ind.B <- (data$ClusterType=='B') & (is.na(data$PrimaryNum))
  size.A <- data[ind.A, ]$ChainSize
  size.AB <- data[ind.AB,]$ChainSize
  prim.AB <- data[ind.AB,]$PrimaryNum
  size.B <- data[ind.B,]$ChainSize
  
  # obtain an initial value from fitted number of negative binomial model
  fnb <- fitdist(c(size.A-1, size.AB - prim.AB), "nbinom")
  k.ini <- as.numeric(fnb$estimate[1])
  R0.ini <- as.numeric(fnb$estimate[2])
  n.p <- n.p
  alp.t = alp.t
  
  # neg lpg likelihood
  negloglike <- function(para){
    R0 <- para[1]
    k <- para[2]
    p <- n.p
    
    m1 = alp.t*(R0/k)
    m2 = R0/k
    
    # A part !!!
    tmp1 <- lgamma(k + size.A - 1) - lgamma(k) - lgamma(size.A) + (size.A-1)*log(m1) - (k + size.A -1)*log(1+m1)
    tmp2 <- lgamma(k + size.A - 1) - lgamma(k) - lgamma(size.A) + (size.A-1)*log(m2) - (k+size.A-1)*log(1+m2)
    A <- log(p*exp(tmp1) + (1-p)*exp(tmp2))
    
    # AB&B combined
    prim.AB = c(prim.AB, rep(1, length(size.B)))
    size.AB = c(size.AB, size.B)
    nnAB <- length(size.AB)
    AB <- rep(NA, nnAB)
    if(nnAB != 0){
      for (j in 1:nnAB){
        s.j <- as.integer(size.AB[j])
        m <- prim.AB[j]
        g_tem = rep(NA, 1+s.j)
        g_tem[1] = s.j*log(1-p) + (s.j-1)*log(m2) -(k*s.j + s.j - 1)*log(1+m2)
        g_tem[s.j+1] = s.j*log(p) + (s.j-1)*log(m1) -(k*s.j + s.j - 1)*log(1+m1)
        for(g in 1:(s.j-1)){
          fk = 0:(s.j-m)
          f_tem = -lgamma(fk+1) - lgamma(s.j-m-fk+1) + lbeta(k*g + fk, k*(s.j-g) + s.j-m-fk) - 
            lbeta(k*g, k*(s.j-g)) + fk*log(m1/(1+m1)) + (s.j-m-fk)*log(m2/(1+m2))
          g_tem[g+1] = lgamma(s.j+1) - lgamma(g+1) - lgamma(s.j-g+1) + g*(log(p) - k*log(1+m1)) + 
            (s.j-g)*(log(1-p) - k*log(1+m2)) + log(sum(exp(f_tem)))
        }
        AB[j] <- log(m) - log(s.j) + lgamma(k*s.j+s.j - m)-lgamma(k*s.j) + log(sum(exp(g_tem)))
      }
    }
    return(-sum(A)-sum(AB))
  }
  
  # maximize the log likelihood by newton-raphson method
  rot <- nlm(f = negloglike, p = c(R0.ini, k.ini))$estimate
  print(paste('Considering asymptomatic, the estimate of R =', rot[1], 'the estimate of k =', rot[2]))
  return(c(rot[1], rot[2]))
}